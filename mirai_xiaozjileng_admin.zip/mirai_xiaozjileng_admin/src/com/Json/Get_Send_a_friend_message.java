package com.Json;

public class Get_Send_a_friend_message {

}
