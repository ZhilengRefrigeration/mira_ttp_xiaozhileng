package com.Json;

public class Set_Friend_messages {
}
